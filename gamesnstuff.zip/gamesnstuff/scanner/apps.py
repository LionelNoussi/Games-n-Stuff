from django.apps import AppConfig


class ScannerConfig(AppConfig):
    name = 'scanner'
    verbose_name = "Daten"
