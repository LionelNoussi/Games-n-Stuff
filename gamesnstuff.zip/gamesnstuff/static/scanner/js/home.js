var input = document.getElementById('student_name');
input.focus();

function moveOnMax(field){
    document.write()
    if(field.value.length >= 8){
        document.getElementById(item).focus();
    }
}